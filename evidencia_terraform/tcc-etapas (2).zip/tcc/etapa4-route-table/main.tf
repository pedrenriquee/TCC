# ============================================================
# ETAPA 4 — Route Table pública
# ============================================================

terraform {
  required_version = ">= 1.3.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = "sa-east-1"
}

data "aws_vpc" "main" {
  filter {
    name   = "tag:Name"
    values = ["minha-vpc"]
  }
}

data "aws_internet_gateway" "igw" {
  filter {
    name   = "tag:Name"
    values = ["meu-igw"]
  }
}

data "aws_subnet" "publica" {
  filter {
    name   = "tag:Name"
    values = ["subnet-publica"]
  }
}

resource "aws_route_table" "publica" {
  vpc_id = data.aws_vpc.main.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = data.aws_internet_gateway.igw.id
  }

  tags = { Name = "rt-publica" }
}

resource "aws_route_table_association" "publica" {
  subnet_id      = data.aws_subnet.publica.id
  route_table_id = aws_route_table.publica.id
}

output "route_table_id" { value = aws_route_table.publica.id }
