# ============================================================
# ETAPA 3 — Internet Gateway
# ============================================================

terraform {
  required_version = ">= 1.3.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = "sa-east-1"
}

data "aws_vpc" "main" {
  filter {
    name   = "tag:Name"
    values = ["minha-vpc"]
  }
}

resource "aws_internet_gateway" "igw" {
  vpc_id = data.aws_vpc.main.id

  tags = { Name = "meu-igw" }
}

output "igw_id" {
  value = aws_internet_gateway.igw.id
}
