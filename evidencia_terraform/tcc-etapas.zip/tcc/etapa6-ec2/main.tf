# ============================================================
# ETAPA 6 — Instância EC2
# ============================================================

terraform {
  required_version = ">= 1.3.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = "sa-east-1"
}

data "aws_subnet" "publica" {
  filter {
    name   = "tag:Name"
    values = ["subnet-publica"]
  }
}

data "aws_security_group" "ec2" {
  filter {
    name   = "tag:Name"
    values = ["SG-EC2"]
  }
}

data "aws_ami" "ubuntu" {
  most_recent = true
  owners      = ["099720109477"] # Canonical

  filter {
    name   = "name"
    values = ["ubuntu/images/hvm-ssd/ubuntu-*-22.04-amd64-server-*"]
  }
}

resource "aws_key_pair" "ec2" {
  key_name   = "minha-key"
  public_key = file("C:/Users/pedro/.ssh/id_rsa.pub")
}

resource "aws_instance" "web" {
  ami                    = data.aws_ami.ubuntu.id
  instance_type          = "t3.micro"
  subnet_id              = data.aws_subnet.publica.id
  vpc_security_group_ids = [data.aws_security_group.ec2.id]
  key_name               = aws_key_pair.ec2.key_name

  tags = { Name = "minha-ec2" }
}

output "ec2_public_ip" {
  value = aws_instance.web.public_ip
}

output "ec2_public_dns" {
  value = aws_instance.web.public_dns
}
