# ============================================================
# ETAPA 8 — RDS MySQL
# ============================================================

terraform {
  required_version = ">= 1.3.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = "sa-east-1"
}

data "aws_subnet" "privada" {
  filter {
    name   = "tag:Name"
    values = ["subnet-privada"]
  }
}

data "aws_subnet" "privada_b" {
  filter {
    name   = "tag:Name"
    values = ["subnet-privada-b"]
  }
}

data "aws_security_group" "rds" {
  filter {
    name   = "tag:Name"
    values = ["SG-RDS"]
  }
}

resource "aws_db_subnet_group" "main" {
  name       = "meu-db-subnet-group"
  subnet_ids = [data.aws_subnet.privada.id, data.aws_subnet.privada_b.id]

  tags = { Name = "meu-db-subnet-group" }
}

resource "aws_db_instance" "mysql" {
  identifier             = "meu-rds"
  engine                 = "mysql"
  engine_version         = "8.0"
  instance_class         = "db.t3.micro"
  allocated_storage      = 20
  storage_type           = "gp2"
  db_name                = "meubanco"
  username               = "admin"
  password               = "SuaSenhaAqui123!"  # troque pela sua senha
  db_subnet_group_name   = aws_db_subnet_group.main.name
  vpc_security_group_ids = [data.aws_security_group.rds.id]
  publicly_accessible    = false
  multi_az               = false
  skip_final_snapshot    = true
  port                   = 3306

  tags = { Name = "meu-rds" }
}

output "rds_endpoint" {
  value = aws_db_instance.mysql.endpoint
}

output "rds_port" {
  value = aws_db_instance.mysql.port
}
