# ============================================================
# ETAPA 1 — VPC
# ============================================================

terraform {
  required_version = ">= 1.3.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = "sa-east-1"
}

resource "aws_vpc" "main" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_support   = true
  enable_dns_hostnames = true

  tags = { Name = "minha-vpc" }
}

output "vpc_id" {
  description = "ID da VPC criada"
  value       = aws_vpc.main.id
}
