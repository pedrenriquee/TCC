# ============================================================
# ETAPA 2 — Subnets
# ============================================================

terraform {
  required_version = ">= 1.3.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = "sa-east-1"
}

data "aws_vpc" "main" {
  filter {
    name   = "tag:Name"
    values = ["minha-vpc"]
  }
}

resource "aws_subnet" "publica" {
  vpc_id                  = data.aws_vpc.main.id
  cidr_block              = "10.0.1.0/24"
  availability_zone       = "sa-east-1a"
  map_public_ip_on_launch = true

  tags = { Name = "subnet-publica" }
}

resource "aws_subnet" "privada" {
  vpc_id            = data.aws_vpc.main.id
  cidr_block        = "10.0.2.0/24"
  availability_zone = "sa-east-1a"

  tags = { Name = "subnet-privada" }
}

# Subnet extra exigida pela AWS para o DB Subnet Group (mín. 2 AZs)
resource "aws_subnet" "privada_b" {
  vpc_id            = data.aws_vpc.main.id
  cidr_block        = "10.0.3.0/24"
  availability_zone = "sa-east-1b"

  tags = { Name = "subnet-privada-b" }
}

output "subnet_publica_id" {
  value = aws_subnet.publica.id
}

output "subnet_privada_id" {
  value = aws_subnet.privada.id
}

output "subnet_privada_b_id" {
  value = aws_subnet.privada_b.id
}
