# ============================================================
# ETAPA 7 — Security Group RDS
# ============================================================

terraform {
  required_version = ">= 1.3.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = "sa-east-1"
}

data "aws_vpc" "main" {
  filter {
    name   = "tag:Name"
    values = ["minha-vpc"]
  }
}

data "aws_security_group" "ec2" {
  filter {
    name   = "tag:Name"
    values = ["SG-EC2"]
  }
}

resource "aws_security_group" "rds" {
  name        = "SG-RDS"
  description = "Permite MySQL (3306) somente do SG-EC2"
  vpc_id      = data.aws_vpc.main.id

  ingress {
    description     = "MySQL do SG-EC2"
    from_port       = 3306
    to_port         = 3306
    protocol        = "tcp"
    security_groups = [data.aws_security_group.ec2.id]
  }

  tags = { Name = "SG-RDS" }
}

output "sg_rds_id" {
  value = aws_security_group.rds.id
}
